<template>
    <form name="login-form" >
          <div class="mb-3">
            <label for="username">Username: </label>
            <input type="text" id="username" v-model="input.username" />
          </div>
          <br>
          <br>
        <div class="mb-3">
           <label for="password">Password: </label>
           <input type="password" id="password" v-model="input.password" />
        </div>
        <br>
          <br>
          <button class="btn btn-outline-dark" type="submit" @click="login">
            Login
          </button>
        </form>
</template>

<script>
/* eslint-disable */
export default{

    name:'LoginPage',
    data(){
    return{
        input:{
            username: "",
            password: ""
        }
    }
  },
  methods:{
    login(){
      console.log(this.$router)
        return false
      if(this.input.username === 'admin' && this.input.password === 'abc'){
        this.$router.push('/welcome');
        
        // console.log(this.input.username,this.input.password)
        // alert(this.input.username,this.input.password)
      }
      else{
        alert('Invalid username or password');
      }
    }
  }
}

</script>

<style scoped>

</style>