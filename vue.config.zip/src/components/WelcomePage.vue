<template>
  <div>
    <h2>Welcome</h2>
    <p>Welcome to our website!</p>
  </div>
</template>

<script>
export default {
  name:'WelcomePage'
}
</script>